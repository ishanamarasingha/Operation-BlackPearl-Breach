
# Operation BlackPearl Breach
## Platform Setup and Testing Documentation

### 1. Project Overview
Operation BlackPearl Breach is a six-stage Capture The Flag (CTF) project developed using the CTFd platform.

The platform uses Docker Compose to manage the application and supporting services.

### 2. Platform Architecture
The following services were configured:

- CTFd 3.7.7: CTF platform
- MariaDB 11.4: Database
- Redis 7 Alpine: Cache
- Docker Compose: Container orchestration

The CTFd platform is accessible locally at:
http://127.0.0.1:8000

### 3. Network Isolation
Two Docker networks were configured:

- Frontend network: Contains the CTFd service.
- Backend network: Contains CTFd, MariaDB and Redis.

The backend network is configured as internal to reduce direct external access to the database and cache services.

Docker network inspection was used to verify the container connections.

Result: PASS

### 4. Database Backup and Restore
A MariaDB database backup was created using mariadb-dump.

The backup was restored into a separate test database named ctfd_restore_test.

Verification:
- Restore command completed successfully.
- 24 database tables were found in the restored database.
- Original CTFd database was not overwritten.

Result: Schema restore PASS.
Full data verification is pending comparison with the original database.

Note: Database backups do not automatically include CTFd uploaded files or application secrets.

### 5. Automated Platform Testing
A Python unittest script was created:

tests/test_platform.py

Three HTTP availability tests were executed:

| Test | Result |
|------|--------|
| CTFd Homepage | PASS |
| CTFd Login Page | PASS |
| CTFd Challenges Page | PASS |

Total Tests: 3
Passed: 3
Failed: 0

Test evidence:
tests/platform_test_results.txt

These tests verify HTTP availability only. They do not verify successful authentication or challenge solving.

### 6. Pending Integration Testing
The following tests will be completed after all six challenges are integrated:

- Stage 1 to Stage 6 challenge availability
- Correct flag acceptance
- Incorrect flag rejection
- Stage progression and unlocking
- Challenge scoring
- End-to-end player journey

### 7. Security Considerations
- Database credentials and application secrets are stored in the .env file.
- The .env file is excluded from Git tracking.
- Database backups are excluded from Git tracking.
- Exposed credentials must be rotated before final submission.

### 8. Conclusion
The basic CTFd platform availability tests passed successfully.

Network separation and database schema restoration were also verified.

Final challenge integration and end-to-end testing remain pending.
