
# Operation BlackPearl Breach

## Project Overview

Operation BlackPearl Breach is a six-stage Capture The Flag (CTF) project designed to develop practical cybersecurity skills.

The platform uses CTFd, Docker Compose, MariaDB, and Redis.

## Project Architecture

The platform consists of:

- CTFd 3.7.7 - CTF management platform
- MariaDB 11.4 - Database
- Redis 7 Alpine - Cache
- Docker Compose - Container management

## Challenge Stages

| Stage | Category | Status |
|-------|----------|--------|
| 1 | OSINT | In development |
| 2 | Web Security - SQL Injection | In development |
| 3 | Cryptography | In development |
| 4 | Steganography | In development |
| 5 | Network Forensics | In development |
| 6 | Linux Investigation | In development |

Challenge content is maintained by the assigned team members and will be integrated into CTFd after completion.

## Requirements

- Docker Desktop
- Docker Compose
- Git
- Python 3

## Installation

Clone the repository:

```powershell
git clone https://github.com/It24101258/Operation-BlackPearl-Breach.git
cd Operation-BlackPearl-Breach
```

Create a local `.env` file containing the required configuration variables:

- `MYSQL_ROOT_PASSWORD`
- `MYSQL_PASSWORD`
- `CTFD_SECRET_KEY`

Use strong, unique values. Never commit `.env` to GitHub.

## Start the Platform

```powershell
docker compose up -d
docker compose ps
```

Open:

http://127.0.0.1:8000

Complete the initial CTFd setup wizard on a fresh installation.

## Stop the Platform

```powershell
docker compose down
```

Do not use `docker compose down -v` unless intentionally deleting persistent data.

## Automated Testing

Run:

```powershell
python -m unittest discover -s tests -p test_platform.py -v
```

The initial platform availability tests passed:

- Homepage: PASS
- Login page: PASS
- Challenges page: PASS

Results: 3/3 PASS.

Test evidence is stored in:

`tests/platform_test_results.txt`

## Database Backup

Create a backup inside the MariaDB container:

```powershell
docker compose exec -T db sh -c 'mariadb-dump -u root -p"$MYSQL_ROOT_PASSWORD" --single-transaction --quick ctfd > /tmp/ctfd_backup.sql'
docker compose cp db:/tmp/ctfd_backup.sql backups/ctfd_backup.sql
```

The `backups/` folder is excluded from Git tracking.

A database restore was tested using a separate database. Full data verification remains pending.

Note: Uploaded challenge files require a separate backup.

## Team Responsibilities

- Member 1: Platform Architecture and Deployment
- Member 2: Stages 1-3 Challenge Development
- Member 3: Stages 4-6 Challenge Development
- Member 4: Integration Testing and Documentation

## Documentation

See `docs/platform_testing.md` for platform testing details.

## Project Status

Platform setup and basic availability testing are complete.

Challenge integration, stage unlocking, end-to-end testing, and final verification are pending.

## Security Notes

- Keep `.env` and database backups out of Git.
- Do not publish challenge flags or organizer-only solutions.
- Use isolated environments for vulnerable challenge services.
- Rotate exposed credentials before final deployment.
