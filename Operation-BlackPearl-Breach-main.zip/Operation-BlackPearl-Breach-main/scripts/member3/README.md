# BP-05 PCAP Solver

## Requirements
Python 3 and Scapy.

## Run
From this scripts directory:

python3 bp05_solver.py ../../challenges/bp05/player/network_capture.pcap

## Method
Reads the PCAP.
Groups server-port-80 TCP payloads by IP addresses and ports.
Orders segments by TCP sequence number.
Separates HTTP headers from the response body.
Extracts SERVER, SSH_PORT, USERNAME, PASSWORD and FLAG fields.

Answers are read from the capture rather than hardcoded.

## Limitations
Designed for this synthetic capture.
Does not implement general TCP retransmission, overlap, sequence-wrap
or multiple-response handling.

## Tests
Positive input: challenge capture, 240 packets, 18 response connections.
Result: recovered the expected flag and connection details.

Negative input: background-only capture, 220 packets, 17 connections.
Result: reported that the required evidence was not found.

## Assistance disclosure
The solver code was supplied through ChatGPT-assisted tutoring.
Running or understanding this code alone does not establish independent
authorship. Record any student-written changes separately and accurately.

## Save recovered evidence
python3 bp05_solver.py ../../challenges/bp05/player/network_capture.pcap \
  --output ../../challenges/bp05/test-output/solver-evidence.txt

The output option saves recovered values as UTF-8 text.
The output file's parent directory must already exist.
If no evidence is found, no output file is written.
An existing output file is left unchanged when no evidence is found.
The output feature was also supplied with ChatGPT assistance.
