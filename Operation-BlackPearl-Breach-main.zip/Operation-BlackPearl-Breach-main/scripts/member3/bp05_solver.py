import argparse
from pathlib import Path
from scapy.all import rdpcap, IP, TCP, Raw

parser = argparse.ArgumentParser(description="Analyse a BP-05 PCAP")
parser.add_argument("pcap", help="Path to the capture file")
parser.add_argument("--output", help="Save recovered evidence to a text file")
args = parser.parse_args()

try:
    packets = rdpcap(args.pcap)
except Exception as error:
    raise SystemExit(f"Could not read PCAP: {error}")

print("Packets loaded:", len(packets))
responses = {}

for packet in packets:
    if IP not in packet or TCP not in packet or Raw not in packet:
        continue
    if packet[TCP].sport != 80:
        continue

    connection = (
        packet[IP].src,
        packet[TCP].sport,
        packet[IP].dst,
        packet[TCP].dport,
    )
    responses.setdefault(connection, []).append(
        (packet[TCP].seq, bytes(packet[Raw].load))
    )

print("HTTP response connections:", len(responses))
results = []

for connection, segments in responses.items():
    segments.sort(key=lambda segment: segment[0])

    # Supports this lab's contiguous segments without retransmissions.
    data = b"".join(payload for sequence, payload in segments)
    headers, separator, body = data.partition(b"\r\n\r\n")

    if not separator or not headers.startswith(b"HTTP/"):
        continue

    fields = {}
    for line in body.decode("utf-8", errors="replace").splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            fields[key.strip()] = value.strip()

    required = ("SERVER", "SSH_PORT", "USERNAME", "PASSWORD", "FLAG")
    if not all(key in fields for key in required):
        continue

    server_ip, server_port, client_ip, client_port = connection
    lines = [
        f"Evidence stream: {server_ip}:{server_port} -> "
        f"{client_ip}:{client_port}"
    ]
    lines.extend(f"{key}={fields[key]}" for key in required)
    results.append("\n".join(lines))

if not results:
    raise SystemExit("No response containing all required evidence fields found.")

report = "\n\n".join(results) + "\n"
print("\n" + report, end="")

if args.output:
    output = Path(args.output)
    try:
        output.write_text(report, encoding="utf-8")
    except OSError as error:
        raise SystemExit(f"Could not save output: {error}")
    print(f"Saved evidence to: {output}")
