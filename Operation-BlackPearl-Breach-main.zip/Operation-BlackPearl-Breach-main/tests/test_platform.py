
import unittest
import urllib.request

BASE_URL = "http://127.0.0.1:8000"


class TestBlackPearlPlatform(unittest.TestCase):

    def check_page(self, path):
        with urllib.request.urlopen(
            BASE_URL + path, timeout=10
        ) as response:
            self.assertEqual(response.status, 200)

    def test_homepage(self):
        self.check_page("/")

    def test_login_page(self):
        self.check_page("/login")

    def test_challenges_page(self):
        self.check_page("/challenges")


if __name__ == "__main__":
    unittest.main(verbosity=2)
