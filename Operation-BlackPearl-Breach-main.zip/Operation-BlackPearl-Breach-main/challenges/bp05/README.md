# BP-05 — Tracing the Exfiltration

Domain: Digital Forensics / Networking
Difficulty: Moderate-Hard
Points: 200

## Requirements
Python 3, Scapy and Wireshark.

## Build
From this bp05 directory, run:

python3 organiser/generate_pcap.py --server 172.18.0.2 --ssh-port 22

The generator writes player/network_capture.pcap.
It creates synthetic packets without sending network traffic.

## Run
Open the player attachment:

wireshark player/network_capture.pcap

## Intended investigation
Inspect HTTP traffic, identify the suspicious internal-transfer request,
and follow its TCP stream to recover the flag and the BP-06 connection details.

## Reset
Restore the approved clean copy:

cp organiser/pristine_network_capture.pcap player/network_capture.pcap

Remove extracted analysis files only from the dedicated test workspace
when preparing a fresh demonstration.

## Platform integration
Upload player/network_capture.pcap as the BP-05 attachment.
Use organiser/challenge-description.txt and organiser/hints.txt.
Configure BP-04 completion as the prerequisite.
Configure the expected flag server-side.

## Deployment status
172.18.0.2:22 is the verified connection from the Kali Docker host.
SSH login with the recovered analyst credentials succeeded.
This container address is not yet pinned and may change on recreation.
For a separate player machine, regenerate the PCAP with the approved
lab host address and SSH port, then repeat the analysis and login tests.

## Access separation
The organiser directory, test-output directory and this implementation
README are for organisers/assessors. Players receive only the PCAP through
the challenge platform.

## Tools and assistance
Packet generation: Scapy.
Packet analysis: Wireshark.
The generator was prepared with ChatGPT assistance.
