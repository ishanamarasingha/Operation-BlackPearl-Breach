# BP-06 Test Results

| Test | Status | Observed result |
|---|---|---|
| Image build and startup | PASS | Container started; SSH server listening |
| Analyst SSH login | PASS | whoami returned analyst |
| Initial intended solution | PASS | Archive extracted; expected final flag recovered |
| Reset state cleanup | PASS | Test marker and recovered directory absent after recreation |
| Address after reset | PASS | Container address remained 172.18.0.2 |
| Archive solution after reset | PASS | Recreated container allowed login and final flag recovery |
| Root login restriction | PASS | Effective config has PermitRootLogin=no; attempted root password login rejected |
| Local IPv4 route check | PASS | Internal network enabled; running container has no IPv4 default route |
| Platform flag validation | Pending | Requires platform integration |
| BP-05 prerequisite | Pending | Requires platform integration |

Known defect resolved:
Fixed-IP recreation initially failed because the network used an
automatically allocated subnet. The dedicated network was recreated
with an explicitly configured subnet.

Deployment limitation:
Current SSH access is verified from the Kali Linux Docker host.
Separate-machine player access requires platform integration testing.

Scope: These checks do not prove complete group-network isolation. Separate-player access and cross-challenge isolation remain integration tests.
