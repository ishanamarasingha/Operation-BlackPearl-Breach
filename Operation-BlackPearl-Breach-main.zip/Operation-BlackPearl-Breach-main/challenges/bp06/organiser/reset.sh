#!/bin/bash
set -euo pipefail

docker image inspect blackpearl-bp06:local >/dev/null
docker network inspect blackpearl-bp06-net >/dev/null

if docker container inspect blackpearl-bp06 >/dev/null 2>&1; then
    docker rm -f blackpearl-bp06
fi

docker run -d \
  --name blackpearl-bp06 \
  --network blackpearl-bp06-net \
  --ip 172.18.0.2 \
  --memory 512m \
  --cpus 1 \
  --pids-limit 128 \
  blackpearl-bp06:local

echo "BP-06 recreated. Expected SSH address: 172.18.0.2:22"
