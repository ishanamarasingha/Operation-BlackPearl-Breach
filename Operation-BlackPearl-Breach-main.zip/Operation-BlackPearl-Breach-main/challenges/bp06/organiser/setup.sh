#!/bin/bash
set -eu

useradd -m -s /bin/bash analyst

mkdir -p /opt/blackpearl/logs /opt/blackpearl/evidence
mkdir -p /usr/local/lib/blackpearl /tmp/final-evidence

cat > /home/analyst/.incident-note <<'NOTE'
BLACKPEARL INCIDENT NOTE

Incident reference: BP-2026

The application audit trail contains the next lead.
Investigate /opt/blackpearl/logs/application.log.
Search for the incident reference rather than reading unrelated entries.
NOTE

cat > /opt/blackpearl/logs/application.log <<'LOG'
2026-09-20T08:00:00 INFO shipment batch=104 status=queued
2026-09-20T08:02:00 INFO healthcheck status=ok
2026-09-20T08:04:00 INFO shipment batch=105 status=processed
2026-09-20T08:07:00 WARN incident=BP-2026 suspicious internal transfer detected
2026-09-20T08:08:00 INFO shipment batch=106 status=queued
2026-09-20T08:09:00 AUDIT incident=BP-2026 review the analyst scheduled task
2026-09-20T08:10:00 AUDIT incident=BP-2026 archive=/opt/blackpearl/evidence/final_evidence.zip
2026-09-20T08:11:00 INFO healthcheck status=ok
LOG

cat > /usr/local/lib/blackpearl/check-evidence.sh <<'TASK'
#!/bin/sh
# Harmless training task: writes only a timestamp to the analyst home.
#
# Evidence archive password rule:
# Use the Stage 1 project codename in UPPERCASE.
# Append the TWO-DIGIT number of the customer-portal stage.
# Use no spaces or separators.
#
# Recover those values from the earlier stages.

date -u '+%Y-%m-%dT%H:%M:%SZ evidence-check' \
  >> /home/analyst/evidence-check.log
TASK

chmod 755 /usr/local/lib/blackpearl/check-evidence.sh

printf '* * * * * /usr/local/lib/blackpearl/check-evidence.sh\n' \
  | crontab -u analyst -

cat > /tmp/final-evidence/final_report.txt <<'REPORT'
OPERATION BLACKPEARL BREACH — FINAL INVESTIGATION

1. Public profile and WHOIS evidence identified BLUEHARBOR.
2. SQL injection in the fictional customer portal exposed a staff memo.
3. Base64 decoding and Vigenere decryption revealed the staff photo.
4. Image metadata and Steghide extraction revealed the PCAP filename.
5. Unencrypted HTTP traffic exposed fictional analyst credentials.
6. Linux notes, logs and a scheduled-task clue led to this archive.

This is a fictional incident created for an isolated educational lab.

Final flag:
BPL{the_entire_attack_chain_was_uncovered}
REPORT

(
  cd /tmp/final-evidence
  zip -q -P 'BLUEHARBOR02' \
    /opt/blackpearl/evidence/final_evidence.zip final_report.txt
)

rm -rf /tmp/final-evidence

chown root:root /home/analyst/.incident-note
chmod 444 /home/analyst/.incident-note
chown -R root:root /opt/blackpearl
chmod 755 /opt/blackpearl /opt/blackpearl/logs /opt/blackpearl/evidence
chmod 444 /opt/blackpearl/logs/application.log
chmod 444 /opt/blackpearl/evidence/final_evidence.zip

mkdir -p /run/sshd
cat > /etc/ssh/sshd_config.d/blackpearl.conf <<'SSH'
PasswordAuthentication yes
KbdInteractiveAuthentication no
PermitRootLogin no
AllowUsers analyst
AllowTcpForwarding no
AllowAgentForwarding no
X11Forwarding no
PermitTunnel no
SSH
