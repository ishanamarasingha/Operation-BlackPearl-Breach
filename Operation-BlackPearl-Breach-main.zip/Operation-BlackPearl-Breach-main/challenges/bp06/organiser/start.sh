#!/bin/sh
set -eu

: "${BP06_ANALYST_PASSWORD:?BP06_ANALYST_PASSWORD is required}"
printf 'analyst:%s\n' "$BP06_ANALYST_PASSWORD" | chpasswd
unset BP06_ANALYST_PASSWORD
mkdir -p /run/sshd
ssh-keygen -A
/usr/sbin/cron
exec /usr/sbin/sshd -D -e
