# BP-06 — The Final Server Investigation

Domain: Linux / System Security
Difficulty: Hard
Points: 250

## Requirements
Docker Engine on Linux and an SSH client.
Tested locally on Kali ARM64 with an Ubuntu 24.04 container.

## Build
From this bp06 directory:

sudo docker build -t blackpearl-bp06:local .

## Network setup
Create the dedicated network if it does not already exist:

sudo docker network create --internal \
  --subnet 172.18.0.0/16 \
  --gateway 172.18.0.1 \
  blackpearl-bp06-net

The subnet must not overlap another host or Docker network.
If an alternative subnet is required, update reset.sh and regenerate
the BP-05 PCAP with the matching address.

## Run or reset
WARNING: Reset removes the dedicated BP-06 container and all player
changes inside it, then recreates it from the built image.

sudo bash organiser/reset.sh

## Connect from the Linux Docker host
ssh analyst@172.18.0.2

Lab-only password: BPL_Lab_Analyst_2026

The container IP is intended for access from this Linux Docker host.
Access from a separate participant machine requires an approved
isolated access arrangement configured by the platform organiser.

## Intended solution
Inspect hidden home files.
Search the application logs for the incident reference.
Inspect the analyst crontab and its harmless script.
Derive the archive password from the earlier-stage clues.
Extract the archive into the analyst home and read the final report.

## SSH keys after reset
Each recreated container generates fresh SSH host keys.
After a known organiser reset, remove the old local lab entry:

ssh-keygen -R 172.18.0.2

Then reconnect and accept the new key for the recreated lab host.

## Isolation
Dedicated internal Docker network.
No host directory or Docker socket mounts.
No privileged mode.
SSH root login and forwarding disabled.
Only the analyst account is allowed to log in.
Memory, CPU and PID limits configured in reset.sh.
Analyst has no sudo privileges.

## Platform integration
Configure BP-05 completion as the prerequisite.
Use organiser/challenge-description.txt and organiser/hints.txt.
Expected flag: BPL{the_entire_attack_chain_was_uncovered}
Validate flags server-side.

## References and assistance
Ubuntu base image; Docker; OpenSSH; cron; zip/unzip.
Configuration and setup code were prepared with ChatGPT assistance.
Organisers must review and understand the implementation.

## Material access
This source package is for organisers and assessors.
Do not provide setup.sh, solutions or this README to players.
