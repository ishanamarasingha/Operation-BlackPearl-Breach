# BP-04 — The Hidden Profile Photo

Category: Steganography
Difficulty: Moderate
Points: 150

## Requirements
ExifTool and Steghide.

## Run
From this bp04 directory:

exiftool -Comment player/staff_photo.jpg

Derive the password: Stage 1 codename lowercase followed by 01.

mkdir -p /tmp/blackpearl-bp04
steghide extract -sf player/staff_photo.jpg \
  -xf /tmp/blackpearl-bp04/hidden_evidence.txt

Enter the derived password interactively.
Read the extracted file for the flag and network_capture.pcap clue.

## Reset
cp organiser/pristine_staff_photo.jpg player/staff_photo.jpg

Before a fresh attempt, remove only the extracted files in the
dedicated participant workspace.

## Platform integration
Player attachment: player/staff_photo.jpg
Prerequisite: BP-03 completion
Expected flag: BPL{the_photo_hid_more_than_pixels}
Use organiser/challenge-description.txt and organiser/hints.txt.

## Access and assistance
Organiser material must not be provided as player downloads.
Implementation was prepared with ChatGPT assistance using
ExifTool, Steghide and Python.
